﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mothercare.Models.Home
{
    public class forlogin
    {
        public bool loginCheck { get; set; }
        public bool verifyCheck { get; set; }
    }
}